<form action="" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Tên danh mục</label>
        <input type="text" class="form-control" id="email" placeholder="Tên danh mục" value="<?php echo e(old('name',isset($category->c_name) ? $category->c_name : '' )); ?>" name="name">
        <?php if($errors->has('name')): ?>
        <div class="error-text">
            <?php echo e($errors->first('name')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="name">Icon</label>
        <input type="text" class="form-control" id="email" placeholder="fa fa-home" name="icon" value="<?php echo e(old('icon',isset($category->c_icon) ? $category->c_icon : '' )); ?>">
        <?php if($errors->has('icon')): ?>
        <div class="error-text">
            <?php echo e($errors->first('icon')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="name">Title</label>
        <input type="text" class="form-control" id="email" placeholder="Title" value="<?php echo e(old('c_title_seo',isset($category->c_title_seo) ? $category->c_title_seo : '')); ?>" name="c_title_seo">
        <?php if($errors->has('c_title_seo')): ?>
        <div class="error-text">
            <?php echo e($errors->first('c_title_seo')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="name">Description</label>
        <input type="text" class="form-control" id="email" placeholder="Meta description" value="<?php echo e(old('c_description_seo',isset($category->c_description_seo) ? $category->c_description_seo : '')); ?>" name="c_description_seo">
        <?php if($errors->has('c_description_seo')): ?>
        <div class="error-text">
            <?php echo e($errors->first('c_description_seo')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <label><input type="checkbox" name="hot">Nổi bật</label>
    </div>
    <button type="submit" class="btn btn-success">Lưu thông tin</button>
    <div class="form-group">

    </div>


</form><?php /**PATH C:\xampp\htdocs\marahubfilms\Modules\Admin\Providers/../Resources/views/category/form.blade.php ENDPATH**/ ?>