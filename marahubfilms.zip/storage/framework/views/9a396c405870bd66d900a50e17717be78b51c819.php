<?php $__env->startSection('content'); ?>

<div class="table-responsive">
<div class="page-header" >
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.get.list.category')); ?>" title="Danh mục">Phim</a></li>
    <li class="breadcrumb-item active" aria-current="page">Danh sách</li>
  </ol>
</nav>
</div>
        <h2>Quản lý danh sách phim
             <a  href="<?php echo e(route('admin.get.create.product')); ?>" class="float-right">Thêm mới</a>
        </h2>
        
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Tên Danh Mục</th>
              <th>Title</th>
              <th>Trạng Thái</th>
              <th>Thao Tác</th>
            </tr>
          </thead>
          <tbody>
             
  
          </tbody>
        </table>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\marahubfilms\Modules\Admin\Providers/../Resources/views/product/index.blade.php ENDPATH**/ ?>