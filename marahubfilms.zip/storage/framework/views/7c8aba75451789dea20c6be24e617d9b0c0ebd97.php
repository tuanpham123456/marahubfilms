<?php $__env->startSection('content'); ?>

<div class="table-responsive">
<div class="page-header" >
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Trang chủ</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.get.list.category')); ?>" title="Danh mục">Danh mục</a></li>
    <li class="breadcrumb-item active" aria-current="page">Danh sách</li>
  </ol>
</nav>
</div>
        <h2>Quản lý danh sách phim
             <a  href="<?php echo e(route('admin.get.create.category')); ?>" class="float-right">Thêm mới</a>
        </h2>
        
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Tên Danh Mục</th>
              <th>Title</th>
              <th>Trạng Thái</th>
              <th>Thao Tác</th>
            </tr>
          </thead>
          <tbody>
              <?php if(isset($categories)): ?>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->c_name); ?></td>
                    <td><?php echo e($category->c_title_seo); ?></td>
                    <td>
                        <a href=""><?php echo e($category->getStatus($category->c_active)['name']); ?></a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.get.edit.category', $category->id)); ?>">Edit</a>
                        <a href="<?php echo e(route('admin.get.action.category', ['delete',$category->id])); ?>">Delete</a>

                    </td>
                  </tr>  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
              <?php endif; ?>
  
          </tbody>
        </table>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\marahubfilms\Modules\Admin\Providers/../Resources/views/category/index.blade.php ENDPATH**/ ?>