<?php $__env->startSection('content'); ?>

<div class="table-responsive">
    <div class="page-header">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Trang chủ</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.get.list.category')); ?>">Danh mục</a></li>
                <li class="breadcrumb-item active" aria-current="page">Thêm mới</li>
            </ol>
        </nav>
    </div>
    <div>
        <form action="" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Tên danh mục</label>
                <input type="text" class="form-control" id="email" placeholder="Tên danh mục" value="<?php echo e(old('name')); ?>" name="name">
                <?php if($errors->has('name')): ?>
                    <div class="error-text">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name">Icon</label>
                <input type="text" class="form-control" id="email" placeholder="fa fa-home"  name="icon" value="<?php echo e(old('name')); ?>">
                <?php if($errors->has('icon')): ?>
                    <div class="error-text">
                        <?php echo e($errors->first('icon')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name">Title</label>
                <input type="text" class="form-control" id="email" placeholder="Title" value="<?php echo e(old('c_title_seo')); ?>" name="c_title_seo">
                <?php if($errors->has('c_title_seo')): ?>
                    <div class="error-text">
                        <?php echo e($errors->first('c_title_seo')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name">Description</label>
                <input type="text" class="form-control" id="email" placeholder="Meta description" value="<?php echo e(old('c_description_seo')); ?>" name="c_description_seo">
                <?php if($errors->has('c_description_seo')): ?>
                    <div class="error-text">
                        <?php echo e($errors->first('c_description_seo')); ?>

                    </div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label><input type="checkbox" name="hot">Nổi bật</label>
            </div>
            <button type="submit" class="btn btn-success">Lưu thông tin</button>
            <div class="form-group">

            </div>

            
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\marahubfilms\Modules\Admin\Providers/../Resources/views/category/create.blade.php ENDPATH**/ ?>